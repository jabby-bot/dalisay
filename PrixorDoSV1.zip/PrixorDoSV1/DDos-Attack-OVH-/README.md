# DDos-Attack-OVH-
Powerful DDoS Attack


pip3 install -r requirements.txt

python3 80port.py or python3 443port.py
