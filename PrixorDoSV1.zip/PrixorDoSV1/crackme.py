import time
while True:
	username = input("Username: ")
	password = input("Password: ")
	if username == "troll" and password == 'troll':
		print("Lols!")
		break
	else:
		print("Wrong!")
		print("Lol you got troll!")