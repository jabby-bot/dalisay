while True:
	username = input("Username: ")
	password = input("Password: ")
	if username == 'admin' and password == 'admin':
		print("Welcome User: " + username)
		break
	else:
		print("Cannot Found User!")